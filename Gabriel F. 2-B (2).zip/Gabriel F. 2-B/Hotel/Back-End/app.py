import os
from flask import Flask, send_from_directory

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__),".."))

FRONTEND_DIR = os.path.join(BASE_DIR, "Front-End")

STATIC_DIR = os.path.join(FRONTEND_DIR, "Static")

app = Flask(__name__, static_folder=STATIC_DIR,static_url_path="/" + STATIC_DIR)


#página principal
@app.route("/")
def home():
    return send_from_directory(FRONTEND_DIR, "index.html")

#página consulta
@app.route("/consulta")
def consulta_page():
    return send_from_directory(FRONTEND_DIR, "consulta.html")

#página alteração
@app.route("/alterar")
def alterar_page():
    return send_from_directory(FRONTEND_DIR, "alterar.html")

if __name__ == "__main__":
    print("BASE_DIR", BASE_DIR)
    print("FRONTEND_DIR", FRONTEND_DIR)
    print("STATIC_DIR", STATIC_DIR)
    app.run(debug=True)




