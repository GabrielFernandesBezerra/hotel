#--------------------------------------------------Bibliotecas importadas----------------------------------------------------------------------------------------------
import os #biblioteca do sistema operacional
from flask import Flask, send_from_directory #biblioteca para criar o servidor
import openpyxl #biblioteca para trabalhar com arquivos excel
from datetime import(
     datetime,
) #biblioteca para trabalhar com datas (nesse caso para pegar as datas dos cadastros)
#--------------------------------------------------------------------------------------------------------------------------------


#----------------------------------------------Variaveis----------------------------------------------------------------------------------------------
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__),".."))

FRONTEND_DIR = os.path.join(BASE_DIR, "Front-End") #localizando a pasta dofront-end

STATIC_DIR = os.path.join(FRONTEND_DIR, "Static") #localizando a pasta do Static (que contem o arquivo css)

DB_DIR = os.path.join(os.path.dirname(__file__), "..", "DB") #banco de dados
EXCEL_FILE = os.path.join(DB_DIR, "clientes.xlsx") #criando o arquivo excel dentro da pasta do DB

# Cabeçalhos das colunas do Excel (linha 1)
COLUMNS = [
    "ID",
    "Nome",
    "CPF",
    "Email",
    "Telefone",
    "Endereço",
    "Observações",
    "DATA_CADASTRO"
]
#-------------------------------------------------------------------------------------------------------------------------------

app = Flask(__name__, static_folder=STATIC_DIR,static_url_path="/" + STATIC_DIR) #criando o servidor

#página principal
@app.route("/")
def home():
    return send_from_directory(FRONTEND_DIR, "index.html")

#página consulta
@app.route("/consulta")
def consulta_page():
    return send_from_directory(FRONTEND_DIR, "consulta.html")

#página alteração
@app.route("/alterar")
def alterar_page():
    return send_from_directory(FRONTEND_DIR, "alterar.html")



if __name__ == "__main__":
    print("BASE_DIR", BASE_DIR)
    print("FRONTEND_DIR", FRONTEND_DIR)
    print("STATIC_DIR", STATIC_DIR)
    app.run(debug=True)




