#-------------------------------------------------\\Bibliotecas importadas//----------------------------------------------------------------------------------------------
import os #biblioteca do sistema operacional
from flask import Flask, send_from_directory, request, jsonify #biblioteca para criar o servidor
import openpyxl #biblioteca para trabalhar com arquivos excel
from datetime import(
     datetime,
) #biblioteca para trabalhar com datas (nesse caso para pegar as datas dos cadastros)
#--------------------------------------------------------------------------------------------------------------------------------


#-------------------------------------------\\Variaveis e Localizações de Pastas/Arquivos//----------------------------------------------------------------------------------------------
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__),".."))

FRONTEND_DIR = os.path.join(BASE_DIR, "Front-End") #localizando a pasta dofront-end

STATIC_DIR = os.path.join(FRONTEND_DIR, "Static") #localizando a pasta do Static (que contem o arquivo css)

DB_DIR = os.path.join(os.path.dirname(__file__), "..", "DB") #banco de dados
EXCEL_FILE = os.path.join(DB_DIR, "clientes.xlsx") #localizando o arquivo excel

# Cabeçalhos das colunas do Excel (linha 1)
COLUMNS = [
    "ID",
    "Nome",
    "CPF",
    "Email",
    "Telefone",
    "Endereço",
    "Observações",
    "DATA_CADASTRO"
]
#-------------------------------------------------------------------------------------------------------------------------------

#-----------------------------------------------------------\\EXCEL//--------------------------------------------------------------------
def init_excel():
    if not os.path.exists(DB_DIR):
        os.makedirs(DB_DIR) #criando o arquivo excel dentro da pasta do DB, caso não tiver

    if not os.path.exists(EXCEL_FILE):
        workbook = openpyxl.Workbook() #cria uma planilha do excel
        sheet = workbook.active #pega uma planilha ativa
        sheet.title = "Clientes" #nomeia a planilha
        sheet.append(COLUMNS) #adiciona as colunas dentro da planilha do excel
        workbook.save(EXCEL_FILE) #salva o arquivo excel
#-------------------------------------------------------------------------------------------------------------------------------

app = Flask(__name__, static_folder=STATIC_DIR,static_url_path="/" + STATIC_DIR) #criando o servidor

#-----------------------------------------------------\\Rota para páginas//--------------------------------------------------------------------------
#página principal
@app.route("/")
def home():
    return send_from_directory(FRONTEND_DIR, "index.html")

#página consulta
@app.route("/consulta")
def consulta_page():
    return send_from_directory(FRONTEND_DIR, "consulta.html")

#página alteração
@app.route("/alterar")
def alterar_page():
    return send_from_directory(FRONTEND_DIR, "alterar.html")

app.route("/assets/<path:filename>")
def assets(filename):
    return send_from_directory("../frontend/assets", filename)

app.route("/cadastrar", methods=["POST"])
def cadastrar_cliente():

    try:
        data = request.json

        required_fields = ["nome", "cpf", "email", "telefone", "endereco"]
        if not all(field in data and data[field] for field in required_fields):
            return jsonify
            (
                {
                    "status": "error",
                    "message": "Todos os campos obrigatórios devem ser preenchidos.",
                },
                400,
            )

        workbook = openpyxl.load_workbook(EXCEL_FILE)
        sheet = workbook.active

        last_id = 0
        if sheet.max_row > 1:
            last_id = sheet.cell(row=sheet.max_row, column=1).value or 0
        new_id = last_id + 1

#Cria uma nova  linha com os dados informados
        novo_cliente = [
            new_id,
            data["nome"],
            data["cpf"],
            data["email"],
            data["telefone"],
            data["endereco"],
            data["observacoes", ""], #Campo opcional
            datetime.now().strftime("%d/%m/%Y"), #Data Atual 
        ]

        sheet.append(novo_cliente) #Adiciona nova linha no Excel
        workbook.save(EXCEL_FILE) #Salva alterações

        return (
            jsonify (
            {
                     "status": "success", 
                            "message": "Cadastro realizado com sucesso!",
                            "id": new_id,
                    #Retorna resposta de sucesso
            }
            ),
            201
        )
    except Exception as e:
        return (
            jsonify({"status": "error", "message": f"Erro ao salvar no servidor: {e}"}),
            500,
        )    
#-------------------------------------------------------------------------------------------------------------------------------


if __name__ == "__main__":
    print("BASE_DIR", BASE_DIR)
    print("FRONTEND_DIR", FRONTEND_DIR)
    init_excel()
    print("STATIC_DIR", STATIC_DIR)
    app.run(debug=True)




