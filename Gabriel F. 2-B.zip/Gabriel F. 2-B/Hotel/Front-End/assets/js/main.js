//Espera o Html carregar
document.addEventListener("DOMContentLoaded", () => {

//pegando o ID do formulário (o <form id="formCadastro">)
    const formCadastro = document.getElementById("formCadastro");

//espera o formulário ser enviado
    formCadastro.addEventListener("submit", function (e) {

//impede o recarregamento automático da página, impedindo o risco da perda de dados no regarregamento
        e.preventDefault();

        const dados = Object.fromEntries(
            new FormData(formCadastro)
        );


//mostra os dados no console
        console.log("Dados capturados:");
        console.log("Nome:", dados.nome); //mostra nome
        console.log("Email", dados.email); //mostra email
        console.log("Telefone", dados.tel); //mostra telefone
        console.log("CPF", dados.cpf); //mostra cpf
        console.log("Endereço", dados.end); //mostra endereço
        console.log("Observações", dados.obs); //mostra observações

        console.log(dados); //mostra todos os dados

});

});