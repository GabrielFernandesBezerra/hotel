//Espera o Html carregar
document.addEventListener("DOMContentLoaded", () => {

//pegando o ID do formulário (o <form id="formCadastro">)
    const formCadastro = document.getElementById("formCadastro");
    if(formCadastro) {

//espera o formulário ser enviado
    formCadastro.addEventListener("submit", async (e) => {

//impede o recarregamento automático da página, impedindo o risco da perda de dados no regarregamento
        e.preventDefault();

        const dados = Object.fromEntries(
            new FormData(formCadastro)
        );

        try {

    //Envia os dados para o Back-End via POST
            const resp = await fetch ('/api/cadastrar', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(dados)
            });

        //recebe a resposta do Flask
            const result = await resp.json();

        //Exibe a mensagem de retorno para o usuário
            document.getElementById('mensagem').innerText = result.message
            
        //limpa o formulário após o envio
            formCadastro.reset(); 
        }
        catch(err){
            //caso algo dê errado
            alert ('Erro de comunicação com o servidor: ' + err);

        }

//mostra os dados no console do inspecionar do navegador
        console.log("Dados capturados:"); //texto :D
        console.log("Nome:", dados.nome); //mostra nome
        console.log("Email", dados.email); //mostra email
        console.log("Telefone", dados.tel); //mostra telefone
        console.log(dados); //mostra todos os dados
       });
    }
    
});
